import { MostrarHTML } from "/js/global.js";

///Componentes ->
document.addEventListener("DOMContentLoaded", (ev) => {
  MostrarHTML();
});
