export const ObtenerDatosConfiguracion = async () => {
  let config = {
    method: "GET",
    headers: { "Content-Type": "application/json" },
  };

  const url = "/js/configuraciones.json";
};
